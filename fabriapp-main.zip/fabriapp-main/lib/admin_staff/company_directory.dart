import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fabriapp/loginui.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

class CompanyDirectory extends StatefulWidget {
  const CompanyDirectory({Key? key}) : super(key: key);

  @override
  _CompanyDirectoryState createState() => _CompanyDirectoryState();
}

class _CompanyDirectoryState extends State<CompanyDirectory> {
  @override
  Widget build(BuildContext context) {
    final _formKey = GlobalKey<FormState>();

    // date
    DateTime selectedDate = DateTime.now();
    bool showDate = false;

    TextEditingController namecont = TextEditingController();
    TextEditingController compcont = TextEditingController();
    TextEditingController contactcont = TextEditingController();
    Future _addContact() async {
      try {
        await FirebaseFirestore.instance.collection('directory').add({
          'name': namecont.text,
          'company': compcont.text,
          'contact_num': contactcont.text
        });

        // ignore: unused_catch_clause
      } on FirebaseAuthException catch (e) {
        print(e);
      }
    }

    Future<DateTime> _selectDate(BuildContext context) async {
      final selected = await showDatePicker(
        context: context,
        initialDate: selectedDate,
        firstDate: DateTime(1940),
        lastDate: DateTime(2022),
      );
      if (selected != null && selected != selectedDate) {
        setState(() {
          selectedDate = selected;
        });
      }
      return selectedDate;
    }

    String getDate() {
      // ignore: unnecessary_null_comparison
      if (selectedDate == null) {
        return 'select date';
      } else {
        return DateFormat('MMM d, yyyy').format(selectedDate);
      }
    }

    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Container(
              child: Text(
                'Add Patient',
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: Colors.grey[800],
                    fontWeight: FontWeight.w900,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Open Sans',
                    fontSize: 20),
              ),
            ),
            const SizedBox(height: 10),
            //
            // mobile
            Form(
              key: _formKey,
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  children: [
                    TextFormField(
                      controller: namecont,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'Enter Name',
                        labelText: 'Name',
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter a Name';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 15),
                    TextFormField(
                      controller: compcont,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'Enter NIC Number',
                        labelText: 'NIC',
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter NIC number';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 15),
                    TextFormField(
                      controller: contactcont,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'Enter Contact Number',
                        labelText: 'Contact Number',
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter a Contact Number';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 15),

                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 15),
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: Colors.green,
                            textStyle: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold)),
                        onPressed: () {
                          _selectDate(context);
                          showDate = true;
                        },
                        child: const Text("Date of Birth"),
                      ),
                    ),

                    showDate
                        ? Center(child: Text(getDate()))
                        : const SizedBox(),
                    //
                    const SizedBox(height: 15),

                    TextFormField(
                      controller: contactcont,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'Enter Address',
                        labelText: 'Address',
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'Please enter a Address';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(
                      height: 30,
                    ),
                    Container(
                      height: 50,
                      width: 250,
                      decoration: BoxDecoration(
                          color: Colors.green,
                          borderRadius: BorderRadius.circular(20)),
                      child: TextButton(
                        onPressed: () {
                          if (_formKey.currentState!.validate()) {
                            // If the form is valid, display a Snackbar.
                            _addContact();

                            ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Data is in processing.')));
                          }
                        },
                        child: const Text(
                          'Create',
                          style: TextStyle(color: Colors.white, fontSize: 25),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      //
    );
  }
}
