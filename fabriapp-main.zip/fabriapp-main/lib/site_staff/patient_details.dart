import 'package:fabriapp/loginui.dart';
import 'package:fabriapp/resetpassword.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';

class PatientsDetails extends StatefulWidget {
  const PatientsDetails({Key? key}) : super(key: key);

  @override
  _PatientsDetailsState createState() => _PatientsDetailsState();
}

class _PatientsDetailsState extends State<PatientsDetails> {
  @override
  Widget build(BuildContext context) {
    Future<void> _signOut() async {
      await FirebaseAuth.instance.signOut();
      Navigator.pop(context);
    }

    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            TextFormField(
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Search NIC number',
                labelText: 'NIC',
              ),
            ),
            const SizedBox(height: 40),

            //
            Container(
              child: Text(
                'Patient Details',
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: Colors.grey[800],
                    fontWeight: FontWeight.w900,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Open Sans',
                    fontSize: 20),
              ),
            ),
            const SizedBox(height: 20),
            //
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(140),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 10,
                    blurRadius: 5,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: const CircleAvatar(
                radius: 60,
                // backgroundImage: AssetImage(""),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              child: Text(
                'Patient Name : ' + 'John',
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: Colors.grey[800],
                    fontWeight: FontWeight.w900,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Open Sans',
                    fontSize: 18),
              ),
            ),
            const SizedBox(height: 10),

            Container(
              child: Text(
                'Blood Group : ' + 'B-',
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: Colors.grey[800],
                    fontWeight: FontWeight.w900,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Open Sans',
                    fontSize: 18),
              ),
            ),
            const SizedBox(height: 10),

            Container(
              child: Text(
                'Allergies : ' + 'Nothing',
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: Colors.grey[800],
                    fontWeight: FontWeight.w900,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Open Sans',
                    fontSize: 18),
              ),
            ),
            const SizedBox(height: 10),

            Container(
              child: Text(
                'Blood Report : ' + 'https://www/google.drive',
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: Colors.grey[800],
                    fontWeight: FontWeight.w900,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Open Sans',
                    fontSize: 18),
              ),
            ),
            const SizedBox(height: 10),

            Container(
              child: Text(
                'Previous Surgeries : ' + 'Leg Surgery',
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: Colors.grey[800],
                    fontWeight: FontWeight.w900,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Open Sans',
                    fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
