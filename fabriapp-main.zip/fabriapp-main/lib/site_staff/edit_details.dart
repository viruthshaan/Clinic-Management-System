import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fabriapp/loginui.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path/path.dart' as p;

class Sendrequest extends StatefulWidget {
  const Sendrequest({Key? key}) : super(key: key);

  @override
  _SendrequestState createState() => _SendrequestState();
}

class _SendrequestState extends State<Sendrequest> {
  //Initially color is set to yellow which will be changed when button is pressed
  final _formKey = GlobalKey<FormState>();
  String dropdownValue = 'A+';
// date
  DateTime selectedDate = DateTime.now();
  bool showDate = false;
// file upload
  PlatformFile? pickedFile;
  late List<File> files;
  FilePickerResult? result;

  Future pickFiles() async {
    result = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result == null) return;
    setState(() => files = result!.paths.map((path) => File(path!)).toList());
  }

  Future uploadFile() async {
    // final path = 'files/user_name';
    //  final file = File(pickedFile!.path!);

    //  final ref = FirebaseStorage.instance.ref().child(path);
    //  ref.putFile(file);
    // final result = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (result == null) return;
    for (var file in files) {
      var i = 0;
      String bs = p.basename(file.path);
      final destination = 'files/$bs';
      try {
        final ref = FirebaseStorage.instance.ref(destination);
        ref.putFile(file);
        i++;
      } on FirebaseException catch (e) {
        print(e);
      }
    }
  }

  Future chooseImage() async {
    final result = await FilePicker.platform.pickFiles();

    if (result == null) return;
    setState(() {
      pickedFile = result.files.first;
    });
  }

  @override
  Widget build(BuildContext context) {
    TextEditingController titlecont = TextEditingController();
    TextEditingController discont = TextEditingController();
    String name = "";
    String site_nam = "";
    String date = "";

    Future _submit() async {
      try {
        await FirebaseFirestore.instance.collection('request').add({
          'title': titlecont.text,
          'discription': discont.text,
          'sendto': name,
          'site_name': site_nam,
          'date': date,
        });

        // ignore: unused_catch_clause
      } on FirebaseAuthException catch (e) {
        print(e);
      }
    }

    return SafeArea(
      child: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            const SizedBox(
              height: 20,
            ),
            //
            Container(
              child: Text(
                'NIC : ' + 'XXXXXX',
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: Colors.grey[800],
                    fontWeight: FontWeight.w900,
                    fontStyle: FontStyle.italic,
                    fontFamily: 'Open Sans',
                    fontSize: 20),
              ),
            ),
            const SizedBox(height: 10),
            //
            Padding(
                padding: const EdgeInsets.all(10.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      TextFormField(
                        controller: titlecont,
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Full Name',
                          labelText: 'Full Name',
                        ),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please enter a Full Name';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          const Text(
                            "Blood Group    ",
                            style: TextStyle(fontSize: 16),
                          ),
                          DropdownButton<String>(
                            value: dropdownValue,
                            icon: const Icon(Icons.arrow_downward),
                            elevation: 16,
                            style: const TextStyle(
                                color: Color.fromARGB(255, 0, 0, 0)),
                            underline: Container(
                              height: 5,
                              color: const Color.fromARGB(255, 0, 0, 0),
                            ),
                            onChanged: (String? newValue) {
                              setState(() {
                                dropdownValue = newValue!;
                              });
                            },
                            items: <String>['A+', 'A-', 'B+', 'B-']
                                .map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 10,
                      ),

                      TextFormField(
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Foods/ Medicine cause Allergy',
                          labelText: 'Allergy',
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      TextFormField(
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Final Blood Report',
                          labelText: 'Blood Report',
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      TextFormField(
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: 'Previous Surgeries',
                          labelText: 'Surgeries',
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      //
                      Container(
                          padding:
                              const EdgeInsets.only(left: 150.0, top: 40.0),
                          child: ElevatedButton(
                            child: const Text('Update'),
                            onPressed: () {
                              // It returns true if the form is valid, otherwise returns false
                              if (_formKey.currentState!.validate()) {
                                name = dropdownValue;
                                // If the form is valid, display a Snackbar.
                                uploadFile();
                                _submit();
                                ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                        content:
                                            Text('Data is in processing.')));
                              }
                            },
                          )),
                    ],
                  ),
                )),
          ],
        ),
      ),
      //
    );
  }
}
