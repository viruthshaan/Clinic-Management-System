import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class CustomSearchDelegate extends SearchDelegate {
  CustomSearchDelegate({
    Key? key,
  })
  //: super(key: key
  //)
  ;
  CollectionReference _firebaseFirestore =
      FirebaseFirestore.instance.collection('busdetails');

  @override
  List<Widget> buildActions(BuildContext context) {
    return <Widget>[
      IconButton(
        icon: Icon(Icons.close),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: _firebaseFirestore.snapshots().asBroadcastStream(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (!snapshot.hasData) {
          return Center(child: CircularProgressIndicator());
        } else {
          // Fetch Data here
          print(snapshot.data);
          return ListView(children: [
            ...snapshot.data!.docs
                .where((QueryDocumentSnapshot<Object?> element) =>
                    element['vehicle_id']
                        .toString()
                        .toLowerCase()
                        .contains(query.toLowerCase()))
                .map((QueryDocumentSnapshot<Object?> data) {
              final String bus_number = data.get('bus_number');
              final String route = data.get('bus_route');
              final String vehicle_id = data.get('vehicle_id');
              final List bus_transactions = data.get('transactions');
              final int bus_balance = data.get('balance');
              final String bus_id = data.id;

              return Card(
                shape: RoundedRectangleBorder(
                  side: BorderSide(
                    color: Colors.black,
                  ),
                  borderRadius: BorderRadius.circular(15.0),
                ),
                child: ListTile(
                  onTap: () {
                    // show all the details
                  },

                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                  leading: Container(
                    padding: EdgeInsets.only(right: 12.0),
                    decoration: new BoxDecoration(
                        border: new Border(
                            right: new BorderSide(
                                width: 5.0,
                                color: Color.fromARGB(255, 0, 0, 0)))),
                    child: Icon(Icons.bus_alert,
                        color: Color.fromARGB(255, 0, 0, 0)),
                  ),
                  title: Text(
                    "Bus Number: ${vehicle_id} ",
                    style: TextStyle(
                        color: Color.fromARGB(255, 0, 0, 0),
                        fontWeight: FontWeight.bold),
                  ),
                  // subtitle: Text("Intermediate", style: TextStyle(color: Colors.white)),

                  subtitle: Row(
                    children: <Widget>[
                      SizedBox(
                        height: 20,
                      ),
                      Text("${route} ",
                          style: TextStyle(color: Color.fromARGB(255, 0, 0, 0)))
                    ],
                  ),
                ),
              );
            })
          ]);
        }
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return //
        //
        StreamBuilder<QuerySnapshot>(
      stream: _firebaseFirestore.snapshots().asBroadcastStream(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (!snapshot.hasData) {
          return Center(child: CircularProgressIndicator());
        } else {
          // Fetch Data here
          print(snapshot.data);
          return ListView(children: [
            ...snapshot.data!.docs
                .where((QueryDocumentSnapshot<Object?> element) =>
                    element['vehicle_id']
                        .toString()
                        .toLowerCase()
                        .contains(query.toLowerCase()))
                .map((QueryDocumentSnapshot<Object?> data) {
              final String bus_number = data.get('bus_number');
              final String route = data.get('bus_route');
              final String vehicle_id = data.get('vehicle_id');
              final List bus_transactions = data.get('transactions');
              final int bus_balance = data.get('balance');
              final String bus_id = data.id;

              return Card(
                shape: RoundedRectangleBorder(
                  side: BorderSide(
                    color: Colors.black,
                  ),
                  borderRadius: BorderRadius.circular(15.0),
                ),
                child: ListTile(
                  onTap: () {},

                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                  leading: Container(
                    padding: EdgeInsets.only(right: 12.0),
                    decoration: new BoxDecoration(
                        border: new Border(
                            right: new BorderSide(
                                width: 5.0,
                                color: Color.fromARGB(255, 0, 0, 0)))),
                    child: Icon(Icons.bus_alert,
                        color: Color.fromARGB(255, 0, 0, 0)),
                  ),
                  title: Text(
                    "Bus Number: ${vehicle_id} ",
                    style: TextStyle(
                        color: Color.fromARGB(255, 0, 0, 0),
                        fontWeight: FontWeight.bold),
                  ),
                  // subtitle: Text("Intermediate", style: TextStyle(color: Colors.white)),

                  subtitle: Row(
                    children: <Widget>[
                      SizedBox(
                        height: 20,
                      ),
                      Text("${route} ",
                          style: TextStyle(color: Color.fromARGB(255, 0, 0, 0)))
                    ],
                  ),
                ),
              );
            })
          ]);
        }
      },
    );

    //
  }
}
