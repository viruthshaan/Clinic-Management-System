package com.example.fabriapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
